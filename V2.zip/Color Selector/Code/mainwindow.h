
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QLineEdit>
#include <QVector>
#include <QMouseEvent>
#include <QSpinBox>
#include <QPushButton>
#include <QGroupBox>
#include <QComboBox>
#include <converter.h>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void sbSet();
    void Con();
    void Disc();
    void update();


public slots:
    void CMYK_up();
    void RGB_up();
    void HSV_up();
    void HSL_up();
    void LAB_up();
    void XYZ_up();
    void HEX_up();
    void ChooseColor();
    void ChooseModels(int);

private:
    Ui::MainWindow *ui;
    QLineEdit *type_HEX = new QLineEdit;
    QGroupBox* Boxes_arr[6]{new QGroupBox,new QGroupBox,new QGroupBox,new QGroupBox,new QGroupBox,new QGroupBox};
    QHBoxLayout *HBoxUp = new QHBoxLayout;
    QHBoxLayout *HBoxDown = new QHBoxLayout;
    QLabel* Color_line = new QLabel(this);
    QWidget *Window = new QWidget();
    QPushButton *color_Button = new QPushButton("Change Color...");



    QLineEdit* RGB_line[3]{new QLineEdit,new QLineEdit,new QLineEdit};
    QLineEdit* CMYK_line[4]{new QLineEdit,new QLineEdit,new QLineEdit,new QLineEdit};
    QLineEdit* HSV_line[3]{new QLineEdit,new QLineEdit,new QLineEdit};
    QLineEdit* HSL_line[3]{new QLineEdit,new QLineEdit,new QLineEdit};
    QLineEdit* XYZ_line[3]{new QLineEdit,new QLineEdit,new QLineEdit};
    QLineEdit* LAB_line[3]{new QLineEdit,new QLineEdit,new QLineEdit};



    QComboBox *CbColorModels = new QComboBox(this);
    QGroupBox* GrBoxes[3];
    QSpinBox* RGB__[3] {new QSpinBox, new QSpinBox, new QSpinBox};

    void paintEvent(QPaintEvent*);
    bool eventFilter(QObject *obj, QEvent *event);




    void input_data();
    void BoxSetting();
    QDoubleSpinBox* CMYK__[4] {new QDoubleSpinBox, new QDoubleSpinBox, new QDoubleSpinBox, new QDoubleSpinBox};
    QDoubleSpinBox* HSV__[3] {new QDoubleSpinBox, new QDoubleSpinBox, new QDoubleSpinBox};
    QDoubleSpinBox* XYZ__[3] {new QDoubleSpinBox, new QDoubleSpinBox, new QDoubleSpinBox};
    QDoubleSpinBox* HSL__[3] {new QDoubleSpinBox, new QDoubleSpinBox, new QDoubleSpinBox};
    QDoubleSpinBox* LAB__[3] {new QDoubleSpinBox, new QDoubleSpinBox, new QDoubleSpinBox};
    QColor CurColor;
    Converter convert;
};
#endif // MAINWINDOW_H

