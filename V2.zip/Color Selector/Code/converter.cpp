#include "converter.h"

#include <cmath>
double static min(double a, double b, double c);
double static max(double a, double b, double c);
double static Hue_to_RGB(double val_1,double val_2,double valH);
Converter::Converter()
{
    hex = "000000";
}

void Converter::setter_RGB(double r,double g,double b)
{
    rgb[0] = double(r);
    rgb[1] = double(g);
    rgb[2] = double(b);

    RGBtoHEX();
    RGBtoCMYK();
    RGBtoHSV();
    RGBtoHSL();
    RGBtoXYZ();
    XYZtoLAB();
}
double Converter::getter_R()const
{
    return (double(rgb[0]));
}

double Converter::getter_G()const
{
    return (double(rgb[1]));
}

double Converter::getter_B()const
{
    return (double(rgb[2]));
}


void Converter::setter_CMYK(double c, double m, double y, double k)
{
    cmyk[0] = double(c)/100;
    cmyk[1] = double(m)/100;
    cmyk[2] = double(y)/100;
    cmyk[3] = double(k)/100;

    CMYKtoRGB();
    RGBtoHEX();
    RGBtoHSV();
    RGBtoHSL();
    RGBtoXYZ();
    XYZtoLAB();
}
double Converter::cmyk_C()const
{
    return (100*(double(cmyk[0])));
}
double Converter::cmyk_M()const
{
    return (100*(double(cmyk[1])));
}
double Converter::cmyk_Y()const
{
    return (100*(double(cmyk[2])));
}

double Converter::cmyk_K()const
{
    return (100*(double(cmyk[3])));
}

void Converter::setter_HSV(double h,double s,double v)
{
    hsv[0] = (double(h) / 360);
    hsv[1] = (double(s) / 100);
    hsv[2] = (double(v) / 100);

    HSVtoRGB();
    RGBtoHEX();
    RGBtoCMYK();
    RGBtoHSL();
    RGBtoXYZ();
    XYZtoLAB();
}
double Converter::hsv_H()const
{
    return (double(hsv[0])*360);
}

double Converter::hsv_S()const
{
    return (double(hsv[1])*100);
}

double Converter::hsv_V()const
{
    return (double(hsv[2])*100);
}

void Converter::setter_HLS(double h,double l,double s)
{
    hsl[0] = (double(h) / 360);
    hsl[1] = (double(l) / 100);
    hsl[2] = (double(s) / 100);

    HSLtoRGB();
    RGBtoHEX();
    RGBtoHSV();
    RGBtoCMYK();
    RGBtoXYZ();
    XYZtoLAB();
}

double Converter::getter_H()const
{
    return (360*(double(hsl[0])));
}

double Converter::getter_L()const
{
    return (100*(double(hsl[1])));
}

double Converter::getter_S()const
{
    return (100*(double(hsl[2])));
}

void Converter::setter_XYZ(double x,double y,double z)
{
    xyz[0]=(double(x));
    xyz[1]=(double(y));
    xyz[2]=(double(z));

    XYZtoLAB();
    XYZtoRGB();
    RGBtoHEX();
    RGBtoCMYK();
    RGBtoHSV();
    RGBtoHSL();
}

double Converter::getter_X()const
{
    return (double(xyz[0]));
}

double Converter::getter_Y()const
{
    return (double(xyz[1]));
}

double Converter::getter_Z()const
{
    return (double(xyz[2]));
}


void Converter::setter_LAB(double l,double a,double b)
{
    lab[0]=(double(l));
    lab[1]=(double(a));
    lab[2]=(double(b));

    LABtoXYZ();
    XYZtoRGB();
    RGBtoHEX();
    RGBtoCMYK();
    RGBtoHSV();
    RGBtoHSL();
}

double Converter::lab_l()const
{
    return (double(lab[0]));
}

double Converter::lab_a()const
{
    return (double(lab[1]));
}

double Converter::lab_b()const
{
    return (double(lab[2]));
}


void Converter::setter_HEX(QString str)
{
    hex = str;

    HEXtoRGB();
    RGBtoCMYK();
    RGBtoHSV();
    RGBtoHSL();
    RGBtoXYZ();
    XYZtoLAB();
}

void Converter::RGBtoHEX()
{
        hex = QString::number(int(rgb[0]),16) + QString::number(int(rgb[1]),16) + QString::number(int(rgb[2]),16);
}

void Converter::HEXtoRGB()
{
    bool ok;
    QString str1(hex[0]);
    str1 += hex[1];
    rgb[0]=str1.toInt(&ok,16);

    QString str2(hex[2]);
    str2 += hex[3];
    rgb[1]=str2.toInt(&ok,16);


    QString str3(hex[4]);
    str3 += hex[5];
    rgb[2]=str3.toInt(&ok,16);
    // С использованием материалов stackoverflow
}

void Converter::RGBtoCMYK()
{
    if (((1- rgb[0]/255) < (1 - rgb[2]/255)) && ((1- rgb[0]/255) < (1 - rgb[1]/255)))
    {
        cmyk[3] = (1 - rgb[0]/255);
    }

    else if ((1 - rgb[1]/255) < (1 - rgb[2]/255))
    {
        cmyk[3] = (1 - rgb[1]/255);
    }
    else
    {
        cmyk[3] = (1 - rgb[2]/255);
    }

    cmyk[0] = (1-rgb[0]/255 - cmyk[3])/(1 - cmyk[3]);
    cmyk[1] = (1-rgb[1]/255 - cmyk[3])/(1 - cmyk[3]);
    cmyk[2] = (1-rgb[2]/255 - cmyk[3])/(1 - cmyk[3]);
}


void Converter::CMYKtoRGB()
{
    rgb[0]= (255*(1 - cmyk[0])*(1 - cmyk[3]));
    rgb[1]= (255*(1 - cmyk[1])*(1 - cmyk[3]));
    rgb[2]= (255*(1 - cmyk[2])*(1 - cmyk[3]));
}




void Converter::RGBtoHSV()
{
    double r = (rgb[0] / 255);
    double g = (rgb[1] / 255);
    double b = (rgb[2] / 255);

    double max_ = min(r, g, b);
    hsv[2] = max_;

    double min_ = max(r, g, b);
    double raznost = max_ - min_;
    if (raznost == 0)
    {
        hsv[0] = 0;
        hsv[1] = 0;
    }
    else
    {
       hsv[1] = raznost / max_;

       double Dr = ((((max_ - r )/6) + (raznost/2))/raznost);
       double Dg = ((((max_ - g )/6) + (raznost/2))/raznost);
       double Db = ((((max_ - b )/6) + (raznost/2))/raznost);
       if(r==max_)
           hsv[0] = Db - Dg;
       else if(g==max_)
           hsv[0] = ( 1 / 3 ) + Dr - Db;
       else if(b==max_)
       {
           hsv[0] = ( 2 / 3 ) + Dg - Dr;
        if (hsv[0]<0 )
        {
            hsv[0]+=1;
        }
        if ( hsv[0] > 1 )
        {
            hsv[0] -= 1;
        }
      }
   }
}
    void Converter::HSVtoRGB()
    {

        if (hsv[1] == 0)
        {
           rgb[0] = hsv[2] * 255;
           rgb[1] = hsv[2] * 255;
           rgb[2] = hsv[2] * 255;
        }
        else
        {
           double h = hsv[0] * 6;
           if (h == 6)
           {
               h = 0;
           }
           int var_i = (int)h;
           double var_1 = hsv[2] * (1-hsv[1] );
           double var_2 = hsv[2] * (1-hsv[1] * (h-var_i));
           double var_3 = hsv[2] * (1-hsv[1] * (1-(h-var_i)));


           double var_r, var_g, var_b;

           if ( var_i == 0 )
           {
               var_r = hsv[2];
               var_g = var_3;
               var_b = var_1;
           }
           else if(var_i == 1)
           {
               var_r = var_2;
               var_g = hsv[2];
               var_b = var_1;
           }
           else if(var_i == 2 )
           {
               var_r = var_1;
               var_g = hsv[2];
               var_b = var_3;
           }
           else if(var_i == 3)
           {
               var_r = var_1;
               var_g = var_2;
               var_b = hsv[2];
           }
           else if (var_i == 4)
           {
               var_r = var_3;
               var_g = var_1;
               var_b = hsv[2];
           }
           else{
               var_r = hsv[2];
               var_g = var_1;
               var_b = var_2;
           }

           rgb[0] = var_r * 255;
           rgb[1] = var_g * 255;
           rgb[2] = var_b * 255;
        }
    }
void Converter::RGBtoHSL()
{
    //R, G and B input range = 0 ÷ 255
    //H, S and L output range = 0 ÷ 1.0

    double r = ( rgb[0] / 255 );
    double g = ( rgb[1] / 255 );
    double b = ( rgb[2] / 255 );

    double min_value = min(r, g, b);   //Min. value of RGB
    double max_value = max(b, g, r);   //Max. value of RGB
    double del_Max = max_value - min_value;           //Delta RGB value

    hsl[1] = ( max_value + min_value )/ 2;

    if ( del_Max == 0 )                     //This is a gray, no chroma...
    {
        hsl[0] = 0;
        hsl[2] = 0;
    }
    else                                    //Chromatic data...
    {
       if ( hsl[1] < 0.5 )
            hsl[2] = del_Max / ( max_value + min_value );
       else
            hsl[2] = del_Max / ( 2 - max_value - min_value );

       double del_R = ( ( ( max_value - r ) / 6 ) + ( del_Max / 2 ) ) / del_Max;
       double del_G = ( ( ( max_value - g ) / 6 ) + ( del_Max / 2 ) ) / del_Max;
       double del_B = ( ( ( max_value - b ) / 6 ) + ( del_Max / 2 ) ) / del_Max;

       if(r == max_value)
            hsl[0] = del_B - del_G;
       else if (g == max_value)
            hsl[0] = ( 1 / 3 ) + del_R - del_B;
       else if(b == max_value)
            hsl[0] = ( 2 / 3 ) + del_G - del_R;

        if ( hsl[0] < 0 )
            hsl[0] += 1;
        if ( hsl[0] > 1 )
            hsl[0] -= 1;
    }
}

void Converter::HSLtoRGB()
{
    if ( hsl[2] == 0 )
    {
       rgb[0] = hsl[1] * 255;
       rgb[1] = rgb[0];
       rgb[2] = rgb[0];
    }
    else
    {
       double val_2;
       if ( hsl[1] < 0.5 )
       {
            val_2 = hsl[1] *(hsl[2]+1);
       }
       else
       {
            val_2 = ( hsl[1] + hsl[2] ) - ( hsl[2] * hsl[1] );
       }

       double val_1 = 2*hsl[1]-val_2;

       rgb[0] = 255 * Hue_to_RGB( val_1, val_2, hsl[0] + ( 1 / 3 ));
       rgb[1] = 255 * Hue_to_RGB( val_1, val_2, hsl[0]);
       rgb[2] = 255 * Hue_to_RGB( val_1, val_2, hsl[0] - ( 1 / 3 ));
    }
}

void Converter::RGBtoXYZ()
{
    double r = rgb[0] / 255;
    double g = rgb[1] / 255;
    double b = rgb[2] / 255;

    if (r > 0.04045)
    {
        r = pow((( r + 0.055 ) / 1.055), 2.4);
    }
    else
    {
        r = r / 12.92;
    }
    if (g > 0.04045)
    {
        g = pow((( g + 0.055 ) / 1.055), 2.4);
    }
    else
    {
        g = g / 12.92;
    }
    if ( b > 0.04045 )
    {
        b = pow(((b + 0.055 ) / 1.055), 2.4);
    }
    else
    {
        b = b / 12.92;
    }

    r *= 100;
    g *= 100;
    b *= 100;

    xyz[0] = r * 0.4124 + g * 0.3576 + b * 0.1805;
    xyz[1] = r * 0.2126 + g * 0.7152 + b * 0.0722;
    xyz[2] = r * 0.0193 + g * 0.1192 + b * 0.9505;
}
void Converter::XYZtoRGB()
{


    double x = double(xyz[0]) / 100;
    double y = double(xyz[1]) / 100;
    double z = double(xyz[2]) / 100;

    double r = x *  3.2406 + (y * (-1.5372)) + z * -0.4986;
    double g = (x * (-0.9689)) + y *  1.8758 + z *  0.0415;
    double b = x *  0.0557 + (y * (-0.2040)) + z *  1.0570;

    if (r > 0.0031308)
    {
            r = 1.055 *  pow(r, 1 / 2.4 ) - 0.055;
    }
    else
    {
            r = 12.92 * r;
    }
    if ( g > 0.0031308 )
    {
            g = 1.055 * pow(g, 1 / 2.4) - 0.055;
    }
    else
    {
            g = 12.92 * g;
    }
    if ( b > 0.0031308 )
    {
            b = 1.055 * pow(b, 1 / 2.4) - 0.055;
    }
    else
    {
            b = 12.92 * b;
    }

    rgb[0] = r * 255;
    rgb[1] = g * 255;
    rgb[2] = b * 255;
}


void Converter::XYZtoLAB()
{
    double x = xyz[0] / 95.047;
    double y = xyz[1] / 100;
    double z = xyz[2] / 108.883;
    if ( x > 0.008856 )
    {
        x = cbrt(x); // кубический корень
    }
    else
    {
        x = ( 7.787 * x ) + ( 16 / 116 );
    }
    if ( y > 0.008856 )
    {
        y = cbrt(y);
    }
    else
    {
        y = ( 7.787 * y ) + ( 16 / 116 );
    }
    if ( z > 0.008856 )
    {
        z = cbrt(z);
    }
    else
    {
        z = ( 7.787 * z ) + ( 16 / 116 );
    }

    lab[0] = (116 * (y)) - 16;
    lab[1] = (( x - y )*500);
    lab[2] = (( y - z )*200 );
}




void Converter::LABtoXYZ()
{

    double y = ((lab[0] + 16) / 116);

    double x = ((lab[1] / 500) + y);


    double z = (y - (lab[2] / 200));


    if ( pow(y,3)  > 0.008856 )
    {
        y = pow(y,3);
    }
    else
    {
        y = ( y - 16 / 116 ) / 7.787;
    }
    if ( pow(x,3)  > 0.008856 )
    {
        x = pow(x,3);
    }
    else
    {
        x = ( x - 16 / 116 ) / 7.787;
    }
    if ( pow(z,3)  > 0.008856 )
    {
        z = pow(z,3);
    }
    else
    {
        z = ( z - 16 / 116 ) / 7.787;
    }

    xyz[0] = x * 95.047;
    xyz[1] = y * 100;
    xyz[2] = z * 108.883;
}








QString Converter::getter_HEX() const
{
    return (hex);
}
double static min(double a, double b, double c)
{
    if ((b > a) && (c > a))
    {
        return a;
    }
    else if(c > b)
        {
            return b;
        }
    else
        {
            return c;
        }

}

double static max(double a, double b, double c)
{
    if ((b < a) && (c < a))
    {
        return a;
    }
    else if(c < b)
        {
            return b;
        }
    else
        {
            return c;
        }
}

double static Hue_to_RGB(double val_1,double val_2,double valH )
{
   if (valH < 0)
       valH += 1;
   if(valH > 1)
       valH -= 1;
   if (( 6 * valH ) < 1)
       return ( val_1 + ( val_2 - val_1 ) * 6 * valH );
   if (( 2 * valH ) < 1)
       return ( val_2 );
   if (( 3 * valH ) < 2)
       return ( val_1 + ( val_2 - val_1 ) * ( ( 2 / 3 ) - valH ) * 6 );
   return ( val_1 );
}
