#ifndef CONVERTER_H
#define CONVERTER_H
#include <QString>

class Converter
{
public:
    Converter();
public:
    void setter_RGB(double r,double g,double b);
    double getter_R()const;
    double getter_G()const;
    double getter_B()const;



    void setter_CMYK(double c, double m, double y, double k);
    double cmyk_C()const;
    double cmyk_M()const;
    double cmyk_Y()const;
    double cmyk_K()const;


    void setter_HSV(double h,double s,double v);
    double hsv_H()const;
    double hsv_S()const;
    double hsv_V()const;


    void setter_HLS(double h,double l ,double s);
    double getter_H()const;
    double getter_L()const;
    double getter_S()const;


    void setter_XYZ(double x,double y,double z);
    double getter_X()const;
    double getter_Y()const;
    double getter_Z()const;



    void setter_LAB(double l,double a,double b);
    double lab_l()const;
    double lab_a()const;
    double lab_b()const;


    void setter_HEX(QString str);


    void RGBtoHEX();
    void HEXtoRGB();


    void RGBtoCMYK();
    void CMYKtoRGB();


    void RGBtoHSV();
    void HSVtoRGB();


    void RGBtoHSL();
    void HSLtoRGB();


    void RGBtoXYZ();
    void XYZtoRGB();


    void XYZtoLAB();
    void LABtoXYZ();

    QString getter_HEX()const;
private:
    QString hex;
    double rgb[3]{0,0,0};
    double cmyk[4]{0,0,0,1};
    double hsv[3]{0,0,0};
    double hsl[3]{0,0,0};
    double xyz[3]{0,0,0};
    double lab[3]{0,0,0};


};

#endif // CONVERTER_H
