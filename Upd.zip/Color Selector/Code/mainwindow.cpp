#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <converter.h>
#include <QColorDialog>
#include <QValidator>
QStringList strlist;
QRegExpValidator *val_HEX = new QRegExpValidator();
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);



    QPalette coloring;
    coloring.setColor(QPalette::Window, QColor(106, 146, 235)); // Установка цвета окна
    coloring.setColor(QPalette::AlternateBase, Qt::black);
    coloring.setColor(QPalette::Base, Qt::black);
    coloring.setColor(QPalette::Text, QColor(13,0,255));
    coloring.setColor(QPalette::Button, Qt::black);
    coloring.setColor(QPalette::ButtonText, QColor(13,0,255));


    qApp->setPalette(coloring);
    qApp->installEventFilter(this);
    this->setCentralWidget(Window);


    // Установка изначального цвета
    this->CurColor = Qt::black;
    this->type_HEX->setText("000000");
    this->convert.setter_HEX("000000");
    //


    // Формат ввода в HEX
    QRegExp hex_format("[0-9A-Fa-f]{6}");
    val_HEX->setRegExp(hex_format);
    this->type_HEX->setValidator(val_HEX);
    //

    // Добавление окошка в цветом(как в интернете)
    this->Color_line->setAutoFillBackground(true);
    this->Color_line->setFixedSize(200,200);
    this->color_Button->setFixedSize(240,80);
    this->type_HEX->setFixedSize(70,50);
    //
   BoxSetting();
   input_data();
   sbSet();
    this->CbColorModels->setFixedSize(220,20);



    strlist << "RGB.LAB.CMYK" << "RGB.CMYK.HSL" << "RGB.XYZ.LAB" << "RGB.HSV.LAB" << "CMYK.LAB.HSV" << "CMYK.RGB.HSL"
            << "CMYK.RGB.HSV" << "RGB.XYZ.HSV" << "HSV.XYZ.LAB" << "CMYK.LAB.RGB" << "XYZ.LAB.HSL" << "RGB.XYZ.HSL "
            << "RGB.XYZ.CMYK" << "CMYK.LAB.XYZ" << "RGB.CMYK.HSV" << "CMYK.HSL.XYZ" << "RGB.HSL.LAB" << "CMYK.XYZ.RGB";




    this->CbColorModels->addItems(strlist);
    connect(this->color_Button,SIGNAL(clicked()),SLOT(ChooseColor()));
    connect(this->CbColorModels,SIGNAL(activated(int)),SLOT(ChooseModels(int)));
    Con();
    ChooseModels(0);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent*)
{
    QPalette qpa;
    qpa.setColor(Color_line->backgroundRole(),this->CurColor);
    Color_line->setPalette(qpa);
}

// Верхнее окошко
void MainWindow::input_data()
{
    QVBoxLayout *VBox = new QVBoxLayout;
    QVBoxLayout *VBoxUp = new QVBoxLayout;

    // Добавление кнопок
    HBoxUp->addWidget(Color_line);
    VBoxUp->addWidget(this->type_HEX);
    VBoxUp->addWidget(this->color_Button);
    VBoxUp->addWidget(CbColorModels);
    HBoxUp->addLayout(VBoxUp);



    // Выравнивание по центру
    HBoxUp->setAlignment(Qt::AlignmentFlag::AlignCenter);

    VBox->addLayout(HBoxUp);
    VBox->addLayout(HBoxDown);

    Window->setLayout(VBox);
    //

}
// Изменение цвета
bool MainWindow::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::MouseButtonPress && obj == this->Color_line)
    {
        ChooseColor();
        return true;
    }
    return false;
}
// Фукнция по получению кода цвета
void MainWindow::ChooseColor()
{
    QColorDialog *RGB = new QColorDialog;
    this->CurColor = RGB->getColor();
    QString s =this->CurColor.name();
    s.remove(0,1);
    this->type_HEX->setText(s);
}
// Различные варианты переноса RGB(18 вариантов)
void MainWindow::ChooseModels(int i)
{
    int j=0;
     while(j<this->HBoxDown->count()) {
         j++;
         QLayoutItem* it = this->HBoxDown->itemAt(j);
         if(it)
         {
             while((it = this->HBoxDown->itemAt(0)))
             {
                  this->HBoxDown->removeItem(it);
                  this->HBoxDown->removeWidget(it->widget());
                  delete it;
             }
         }
    }
    for(int j = 0; j < 3; j++)
    {
        GrBoxes[j]->hide();
    }
    switch(i)
    {
    case 0:
    {
        GrBoxes[0]=Boxes_arr[0];
        GrBoxes[1]=Boxes_arr[5];
        GrBoxes[2]=Boxes_arr[1];
        break;
    }
    case 1:
    {
        GrBoxes[0]=Boxes_arr[0];
        GrBoxes[1]=Boxes_arr[1];
        GrBoxes[2]=Boxes_arr[3];
        break;
    }
    case 2:
    {
        GrBoxes[0]=Boxes_arr[0];
        GrBoxes[1]=Boxes_arr[4];
        GrBoxes[2]=Boxes_arr[5];
        break;
    }
    case 3:
    {
        GrBoxes[0]=Boxes_arr[0];
        GrBoxes[1]=Boxes_arr[2];
        GrBoxes[2]=Boxes_arr[5];
        break;
    }
    case 4:
    {
        GrBoxes[0]=Boxes_arr[1];
        GrBoxes[1]=Boxes_arr[5];
        GrBoxes[2]=Boxes_arr[2];
        break;
    }
    case 5:
    {
        GrBoxes[0]=Boxes_arr[1];
        GrBoxes[1]=Boxes_arr[0];
        GrBoxes[2]=Boxes_arr[3];
        break;
    }
    case 6:
    {
        GrBoxes[0]=Boxes_arr[1];
        GrBoxes[1]=Boxes_arr[0];
        GrBoxes[2]=Boxes_arr[2];
        break;
    }
    case 7:
    {
        GrBoxes[0]=Boxes_arr[0];
        GrBoxes[1]=Boxes_arr[4];
        GrBoxes[2]=Boxes_arr[2];
        break;
    }
    case 8:
    {
        GrBoxes[0]=Boxes_arr[2];
        GrBoxes[1]=Boxes_arr[4];
        GrBoxes[2]=Boxes_arr[5];
        break;
    }
    case 9:
    {
        GrBoxes[0]=Boxes_arr[1];
        GrBoxes[1]=Boxes_arr[5];
        GrBoxes[2]=Boxes_arr[0];
        break;
    }
    case 10:
    {
        GrBoxes[0]=Boxes_arr[4];
        GrBoxes[1]=Boxes_arr[5];
        GrBoxes[2]=Boxes_arr[3];
        break;
    }
    case 11:
    {
        GrBoxes[0]=Boxes_arr[0];
        GrBoxes[1]=Boxes_arr[4];
        GrBoxes[2]=Boxes_arr[3];
        break;
    }
    case 12:
    {
        GrBoxes[0]=Boxes_arr[0];
        GrBoxes[1]=Boxes_arr[4];
        GrBoxes[2]=Boxes_arr[1];
        break;
    }
    case 13:
    {
        GrBoxes[0]=Boxes_arr[1];
        GrBoxes[1]=Boxes_arr[5];
        GrBoxes[2]=Boxes_arr[4];
        break;
    }
    case 14:
    {
        GrBoxes[0]=Boxes_arr[0];
        GrBoxes[1]=Boxes_arr[1];
        GrBoxes[2]=Boxes_arr[2];
        break;
    }
    case 15:
    {
        GrBoxes[0]=Boxes_arr[1];
        GrBoxes[1]=Boxes_arr[3];
        GrBoxes[2]=Boxes_arr[4];
        break;
    }
    case 16:
    {
        GrBoxes[0]=Boxes_arr[0];
        GrBoxes[1]=Boxes_arr[3];
        GrBoxes[2]=Boxes_arr[5];
        break;
    }
    case 17:
    {
        GrBoxes[0]=Boxes_arr[1];
        GrBoxes[1]=Boxes_arr[4];
        GrBoxes[2]=Boxes_arr[0];
        break;
    }
    }
    for(int j = 0; j < 3; j++)
    {
        this->HBoxDown->addWidget(GrBoxes[j]);
        GrBoxes[j]->show();
    }
}

void MainWindow::BoxSetting()
{
    // Настройки для типа: RGB

    this->Boxes_arr[0]->setTitle("RedGreenBlue");



    QVBoxLayout *RGB_box = new QVBoxLayout;
    QHBoxLayout *box_RED = new QHBoxLayout;
    QHBoxLayout *box_GREEN = new QHBoxLayout;
    QHBoxLayout *box_BLUE = new QHBoxLayout;




    box_RED->addWidget(new QLabel("RED:"));
    box_RED->addWidget(this->RGB__[0]);
    box_GREEN->addWidget(new QLabel("GREEN:"));
    box_GREEN->addWidget(this->RGB__[1]);
    box_BLUE->addWidget(new QLabel("BLUE:"));
    box_BLUE->addWidget(this->RGB__[2]);



    RGB_box->addLayout(box_RED);
    RGB_box->addLayout(box_BLUE);
    RGB_box->addLayout(box_GREEN);


    RGB_box->setAlignment(Qt::AlignmentFlag::AlignCenter);
    this->Boxes_arr[0]->setLayout(RGB_box);

    // Настройки для типа: CMYK
    this->Boxes_arr[1]->setTitle("CyanMagYelKey");

    QVBoxLayout *CMYK_box = new QVBoxLayout;
    QHBoxLayout *CYAN = new QHBoxLayout;
    QHBoxLayout *MAGENTA = new QHBoxLayout;
    QHBoxLayout *YELLOW = new QHBoxLayout;
    QHBoxLayout *KEY = new QHBoxLayout;



    CYAN->addWidget(new QLabel("Cyan:"));
    CYAN->addWidget(this->CMYK__[0]);
    MAGENTA->addWidget(new QLabel("Mag:"));
    MAGENTA->addWidget(this->CMYK__[1]);
    YELLOW->addWidget(new QLabel("Yellow:"));
    YELLOW->addWidget(this->CMYK__[2]);
    KEY->addWidget(new QLabel("Key:"));
    KEY->addWidget(this->CMYK__[3]);


    CMYK_box->addLayout(CYAN);
    CMYK_box->addLayout(MAGENTA);
    CMYK_box->addLayout(YELLOW);
    CMYK_box->addLayout(KEY);
    this->Boxes_arr[1]->setLayout(CMYK_box);
    CMYK_box->setAlignment(Qt::AlignmentFlag::AlignCenter);



    // Настройки для типа: HSV
    this->Boxes_arr[2]->setTitle("HSV");
    QVBoxLayout *HSV_box = new QVBoxLayout;
    QHBoxLayout *Hue = new QHBoxLayout;
    QHBoxLayout *Satur = new QHBoxLayout;
    QHBoxLayout *Val = new QHBoxLayout;

    Hue->addWidget(new QLabel("Hue:"));
    Hue->addWidget(this->HSV__[0]);
    Satur->addWidget(new QLabel("Satur:"));
    Satur->addWidget(this->HSV__[1]);
    Val->addWidget(new QLabel("Value:"));
    Val->addWidget(this->HSV__[2]);


    HSV_box->addLayout(Hue);
    HSV_box->addLayout(Satur);
    HSV_box->addLayout(Val);

    this->Boxes_arr[2]->setLayout(HSV_box);
    HSV_box->setAlignment(Qt::AlignmentFlag::AlignCenter);


    // Настройки для типа: HSL
    this->Boxes_arr[3]->setTitle("HueSatLig");
    QVBoxLayout *HSL_box = new QVBoxLayout;
    QHBoxLayout *Hue_ = new QHBoxLayout;
    QHBoxLayout *Satur_ = new QHBoxLayout;
    QHBoxLayout *Light = new QHBoxLayout;


    Hue_->addWidget(new QLabel("Hue:"));
    Hue_->addWidget(this->HSL__[0]);
    Satur_->addWidget(new QLabel("Satur:"));
    Satur_->addWidget(this->HSL__[1]);
    Light->addWidget(new QLabel("Light:"));
    Light->addWidget(this->HSL__[2]);


    HSL_box->addLayout(Hue_);
    HSL_box->addLayout(Satur_);
    HSL_box->addLayout(Light);

    this->Boxes_arr[3]->setLayout(HSL_box);
    HSL_box->setAlignment(Qt::AlignmentFlag::AlignCenter);



    // Настройки для типа: XYZ
    this->Boxes_arr[4]->setTitle("XYZ");
    QVBoxLayout *XYZ_box = new QVBoxLayout;
    QHBoxLayout *X_b = new QHBoxLayout;
    QHBoxLayout *Y_b = new QHBoxLayout;
    QHBoxLayout *Z_b = new QHBoxLayout;



    X_b->addWidget(new QLabel("X:"));
    X_b->addWidget(this->XYZ__[0]);
    Y_b->addWidget(new QLabel("Y:"));
    Y_b->addWidget(this->XYZ__[1]);
    Z_b->addWidget(new QLabel("Z:"));
    Z_b->addWidget(this->XYZ__[2]);



    XYZ_box->addLayout(X_b);
    XYZ_box->addLayout(Y_b);
    XYZ_box->addLayout(Z_b);


    this->Boxes_arr[4]->setLayout(XYZ_box);
    XYZ_box->setAlignment(Qt::AlignmentFlag::AlignCenter);



    // Настройки для типа: LAB
    this->Boxes_arr[5]->setTitle("L.A.B");
    QVBoxLayout *LAB_box = new QVBoxLayout;
    QHBoxLayout *L_l = new QHBoxLayout;
    QHBoxLayout *A_l = new QHBoxLayout;
    QHBoxLayout *B_l = new QHBoxLayout;

    L_l->addWidget(new QLabel("L:"));
    L_l->addWidget(this->LAB__[0]);
    A_l->addWidget(new QLabel("A:"));
    A_l->addWidget(this->LAB__[1]);
    B_l->addWidget(new QLabel("B:"));
    B_l->addWidget(this->LAB__[2]);


    LAB_box->addLayout(L_l);
    LAB_box->addLayout(A_l);
    LAB_box->addLayout(B_l);


    this->Boxes_arr[5]->setLayout(LAB_box);
    LAB_box->setAlignment(Qt::AlignmentFlag::AlignCenter);


    this->GrBoxes[0]=Boxes_arr[0];
    this->GrBoxes[1]=Boxes_arr[1];
    this->GrBoxes[2]=Boxes_arr[2];
}

void MainWindow::HEX_up()
{

    Disc();
    QString hex = this->type_HEX->text();
    convert.setter_HEX(hex);
    update();

}

// Обновление ячейки "RGB"
void MainWindow::RGB_up()
{

    Disc();


    int red_ = this->RGB__[0]->value();
    int green_ = this->RGB__[1]->value();
    int blue_ = this->RGB__[2]->value();
    convert.setter_RGB(red_, green_, blue_);
    update();

}
void MainWindow::CMYK_up()
{

    Disc();
    double c = this->CMYK__[0]->value();
    double m = this->CMYK__[1]->value();
    double y = this->CMYK__[2]->value();
    double k = this->CMYK__[3]->value();
    convert.setter_CMYK(c, m, y, k);
    update();

}
void MainWindow::HSV_up()
{

    Disc();
    double h = this->HSV__[0]->value();
    double s = this->HSV__[1]->value();
    double v = this->HSV__[2]->value();
    convert.setter_HSV(h, s, v);
    update();

}
void MainWindow::HSL_up()
{

    Disc();
    double h = this->HSL__[0]->value();
    double l = this->HSL__[1]->value();
    double s = this->HSL__[2]->value();
    convert.setter_HLS(h, s, l);
    update();

}
void MainWindow::XYZ_up()
{

    Disc();
    double x = this->XYZ__[0]->value();
    double y = this->XYZ__[1]->value();
    double z = this->XYZ__[2]->value();
    convert.setter_XYZ(x, y, z);
    update();

}
void MainWindow::LAB_up()
{

    Disc();
    double l = this->LAB__[0]->value();
    double a = this->LAB__[1]->value();
    double b = this->LAB__[2]->value();
    convert.setter_LAB(l, a, b);
    update();

}
void MainWindow::update()
{
    this->type_HEX->setText(convert.getter_HEX());
    this->RGB__[0]->setValue(convert.getter_R());
    this->RGB__[1]->setValue(convert.getter_G());
    this->RGB__[2]->setValue(convert.getter_B());

    this->CMYK__[0]->setValue(convert.cmyk_C());
    this->CMYK__[1]->setValue(convert.cmyk_M());
    this->CMYK__[2]->setValue(convert.cmyk_Y());
    this->CMYK__[3]->setValue(convert.cmyk_K());

    this->HSV__[0]->setValue(convert.hsv_H());
    this->HSV__[1]->setValue(convert.hsv_S());
    this->HSV__[2]->setValue(convert.hsv_V());

    this->HSL__[0]->setValue(convert.getter_H());
    this->HSL__[1]->setValue(convert.getter_S());
    this->HSL__[2]->setValue(convert.getter_L());

    this->XYZ__[0]->setValue(convert.getter_X());
    this->XYZ__[1]->setValue(convert.getter_Y());
    this->XYZ__[2]->setValue(convert.getter_Z());

    this->LAB__[0]->setValue(convert.lab_l());
    this->LAB__[1]->setValue(convert.lab_a());
    this->LAB__[2]->setValue(convert.lab_b());

    this->CurColor.setNamedColor("#"+this->type_HEX->text());
    Con();
}

// Настройки ограничения
void MainWindow::sbSet()
{
    for (int i = 0; i < 3; i++)
    {
        this->RGB__[i]->setRange(0,255);
        this->HSV__[i]->setSingleStep(1);
        this->HSL__[i]->setSingleStep(1);
        this->XYZ__[i]->setSingleStep(1);
        this->LAB__[i]->setSingleStep(1);
    }
    for (int i = 0; i < 4; i++)
    {
        this->CMYK__[i]->setRange(0,100);
        this->CMYK__[i]->setSingleStep(1);
    }
    this->HSV__[0]->setRange(0,360);
    this->HSV__[1]->setRange(0,100);
    this->HSV__[2]->setRange(0,100);
    this->HSL__[0]->setRange(0,360);
    this->HSL__[1]->setRange(0,100);
    this->HSL__[2]->setRange(0,100);
    this->XYZ__[0]->setRange(0,95.047);
    this->XYZ__[1]->setRange(0,100);
    this->XYZ__[2]->setRange(0,108.883);
    this->LAB__[0]->setRange(0,100);
    this->LAB__[1]->setRange(-128,128);
    this->LAB__[2]->setRange(-128,128);
}

void MainWindow::Con()
{
    for (int i = 0; i < 3; i++)
    {
        connect(this->RGB__[i],SIGNAL(valueChanged(int)),SLOT(RGB_up()));
        connect(this->CMYK__[i],SIGNAL(valueChanged(double)),SLOT(CMYK_up()));
        connect(this->HSL__[i],SIGNAL(valueChanged(double)),SLOT(HSL_up()));
        connect(this->HSV__[i],SIGNAL(valueChanged(double)),SLOT(HSV_up()));
        connect(this->XYZ__[i],SIGNAL(valueChanged(double)),SLOT(XYZ_up()));
        connect(this->LAB__[i],SIGNAL(valueChanged(double)),SLOT(LAB_up()));
    }
    connect(this->CMYK__[3],SIGNAL(valueChanged(double)),SLOT(CMYK_up()));
    connect(this->type_HEX,SIGNAL(textChanged(QString)),SLOT(HEX_up()));
}
void MainWindow::Disc()
{
    for (int i = 0; i < 3; i++)
    {
        disconnect(this->RGB__[i],SIGNAL(valueChanged(int)),this,SLOT(RGB_up()));
        disconnect(this->CMYK__[i],SIGNAL(valueChanged(double)),this,SLOT(CMYK_up()));
        disconnect(this->HSL__[i],SIGNAL(valueChanged(double)),this,SLOT(HSL_up()));
        disconnect(this->HSV__[i],SIGNAL(valueChanged(double)),this,SLOT(HSV_up()));
        disconnect(this->XYZ__[i],SIGNAL(valueChanged(double)),this,SLOT(XYZ_up()));
        disconnect(this->LAB__[i],SIGNAL(valueChanged(double)),this,SLOT(LAB_up()));
    }
    disconnect(this->CMYK__[3],SIGNAL(valueChanged(double)),this,SLOT(CMYK_up()));
    disconnect(this->type_HEX,SIGNAL(textChanged(QString)),this,SLOT(HEX_up()));
}
